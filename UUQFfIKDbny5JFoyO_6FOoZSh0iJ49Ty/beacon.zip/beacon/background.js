const COURSES = {
  burnaby: {
    domain: 'golfburnaby.cps.golf',
    bookingUrl: 'https://golfburnaby.cps.golf/onlineresweb/search-teetime?TeeOffTimeMin=0&TeeOffTimeMax=23',
    headers: {
      'client-id': 'onlineresweb',
      'x-apikey': '8ea2914e-cac2-48a7-a3e5-e0f41350bf3a',
      'x-componentid': '1',
      'x-ismobile': 'true',
      'x-moduleid': '7',
      'x-productid': '1',
      'x-siteid': '1',
      'x-terminalid': '3',
      'x-timezone-offset': '420',
      'x-timezoneid': 'America/Vancouver',
      'x-websiteid': '68ffa70d-4c31-4511-f6c6-08db3507e474',
    }
  },
  vancouver: {
    domain: 'golfvancouver.cps.golf',
    bookingUrl: 'https://golfvancouver.cps.golf/onlineresweb/search-teetime?TeeOffTimeMin=0&TeeOffTimeMax=23',
    headers: {
      'client-id': 'onlineresweb',
      'x-apikey': '8ea2914e-cac2-48a7-a3e5-e0f41350bf3a',
      'x-componentid': '1',
      'x-ismobile': 'false',
      'x-moduleid': '7',
      'x-productid': '1',
      'x-siteid': '6',
      'x-terminalid': '3',
      'x-timezone-offset': '420',
      'x-timezoneid': 'America/Vancouver',
      'x-websiteid': '2957df8d-a5c0-40e2-6586-08dd13a88838',
    }
  }
};

// EmailJS config — update when new account is ready
const EMAILJS_SERVICE_ID = 'service_abfh21e';
const EMAILJS_TEMPLATE_ID = 'template_mo1bcrc';
const EMAILJS_PUBLIC_KEY = 'nnHeXlCFbfj9c9_BS';

function makeUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

function timeToDecimal(hhmm) {
  const [h, m] = hhmm.split(':').map(Number);
  return h + m / 60;
}

function friendlyDate(dateStr, short = false) {
  const d = new Date(dateStr + 'T12:00:00');
  return short
    ? d.toLocaleDateString('en-CA', { weekday: 'short', month: 'short', day: 'numeric' })
    : d.toLocaleDateString('en-CA', { weekday: 'long', month: 'long', day: 'numeric' });
}

function parseTwilightLabel(itemDesc) {
  if (!itemDesc) return '';
  const desc = itemDesc.toUpperCase();
  if (desc.includes('1ST TWI')) return '1st Twi';
  if (desc.includes('2ND TWI')) return '2nd Twi';
  if (desc.includes('SUNSET')) return 'Sunset';
  if (desc.includes(' TW ') || desc.includes(' TW S') || desc.endsWith('TW')) return 'Twi';
  if (desc.includes(' F9 ') || desc.includes('F9 S')) return 'Twi';
  return '';
}

function cleanCourseName(name) {
  return (name || '').replace(/Golf Course/gi, '').trim();
}

function cleanCourseLabel(label) {
  return (label || '').replace(/\bcourses\b/gi, '').replace(/\s+/g, ' ').trim();
}

function cleanTwilightLabel(label) {
  return (label || '').replace(/^Twilight$/, 'Twi');
}

async function sendEmailAlert(toEmail, monitor, slots, bookingUrl) {
  try {
    const timesList = slots.map(s =>
      [s.label, cleanCourseName(s.courseName), cleanTwilightLabel(s.twilightLabel), s.priceLabel].filter(Boolean).join(' · ')
    ).join('\n');

    const dateStr = friendlyDate(monitor.date);
    const playersLabel = monitor.players === '0' ? 'Any' : monitor.players;

    const res = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        service_id: EMAILJS_SERVICE_ID,
        template_id: EMAILJS_TEMPLATE_ID,
        user_id: EMAILJS_PUBLIC_KEY,
        template_params: {
          to_email: toEmail,
          course: cleanCourseLabel(monitor.label),
          date: dateStr,
          players: playersLabel,
          times: timesList,
          booking_url: bookingUrl
        }
      })
    });
    console.log('EmailJS response:', res.status);
    return res.ok;
  } catch (e) {
    console.error('EmailJS error:', e);
    return false;
  }
}

async function fetchTeeTimes(monitor) {
  const city = COURSES[monitor.city];
  const searchDate = encodeURIComponent(new Date(monitor.date + 'T12:00:00').toDateString());
  const minDec = timeToDecimal(monitor.timeFrom);
  const maxDec = timeToDecimal(monitor.timeTo);
  const transactionId = makeUUID();

  const HEADERS = {
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json',
    'Origin': 'https://' + city.domain,
    'Referer': 'https://' + city.domain + '/onlineresweb/search-teetime',
    'cache-control': 'no-cache, no-store, must-revalidate',
    'pragma': 'no-cache',
    'expires': 'Sat, 01 Jan 2000 00:00:00 GMT',
    'x-requestid': makeUUID(),
    ...city.headers
  };

  const regRes = await fetch(`https://${city.domain}/onlineres/onlineapi/api/v1/onlinereservation/RegisterTransactionId`, {
    method: 'POST',
    headers: HEADERS,
    body: JSON.stringify({ transactionId })
  });
  if (!regRes.ok) throw new Error('Session error: HTTP ' + regRes.status);

  const url = `https://${city.domain}/onlineres/onlineapi/api/v1/onlinereservation/TeeTimes`
    + '?searchDate=' + searchDate
    + '&holes=0'
    + '&numberOfPlayer=' + monitor.players
    + '&courseIds=' + encodeURIComponent(monitor.courseIds)
    + '&searchTimeType=0'
    + '&transactionId=' + transactionId
    + '&teeOffTimeMin=' + Math.floor(minDec)
    + '&teeOffTimeMax=' + Math.ceil(maxDec)
    + '&isChangeTeeOffTime=true'
    + '&teeSheetSearchView=5'
    + '&classCode=R'
    + '&defaultOnlineRate=N'
    + '&isUseCapacityPricing=false'
    + '&memberStoreId=1'
    + '&searchType=1';

  const res = await fetch(url, { headers: HEADERS });
  if (!res.ok) throw new Error('HTTP ' + res.status);
  return await res.json();
}

function parseSlots(data, minTime, maxTime, players) {
  const minDec = timeToDecimal(minTime);
  const maxDec = timeToDecimal(maxTime);
  const playerCount = parseInt(players);
  const slots = [];
  const raw = data.content;
  const items = Array.isArray(raw) ? raw : (raw ? [raw] : []);

  items.forEach(item => {
    const startTime = item.startTime || '';
    if (!startTime) return;
    const timePart = startTime.split('T')[1] || '';
    const [h, m] = timePart.split(':').map(Number);
    const timeDec = h + m / 60;
    if (timeDec < minDec || timeDec > maxDec) return;
    const availablePlayers = item.availableParticipantNo || [];
    if (playerCount > 0 && !availablePlayers.includes(playerCount)) return;
    const label = (h % 12 || 12) + ':' + String(m).padStart(2, '0') + ' ' + (h < 12 ? 'AM' : 'PM');
    const courseName = item.courseName || '';
    const itemDesc = item.shItemPrices && item.shItemPrices[0] ? item.shItemPrices[0].itemDesc : '';
    const price = item.shItemPrices && item.shItemPrices[0] ? item.shItemPrices[0].displayPrice : null;
    const priceLabel = price ? '$' + price.toFixed(2) : '';
    const twilightLabel = parseTwilightLabel(itemDesc);
    slots.push({ label, courseName, priceLabel, twilightLabel, key: startTime });
  });

  return slots;
}

async function updateIcon(enabled) {
  const path = enabled
    ? { 16: 'icon16.png', 48: 'icon48.png', 128: 'icon128.png' }
    : { 16: 'icon16-off.png', 48: 'icon48-off.png', 128: 'icon128-off.png' };
  await chrome.action.setIcon({ path });
}

async function isEnabled() {
  const { beaconEnabled = true } = await chrome.storage.local.get('beaconEnabled');
  return beaconEnabled;
}

async function clearAllAlarms() {
  const { monitors = [] } = await chrome.storage.local.get('monitors');
  for (const m of monitors) {
    await chrome.alarms.clear('monitor-' + m.id);
  }
}

async function runCheck(monitorId) {
  if (!await isEnabled()) return;

  const { monitors = [], log = [], dismissedSlots = {} } = await chrome.storage.local.get(['monitors', 'log', 'dismissedSlots']);
  const idx = monitors.findIndex(m => String(m.id) === String(monitorId));
  if (idx === -1) return;

  const m = monitors[idx];

  // Skip if manually paused by user
  if (m.status === 'paused') return;

  const checkedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  // Auto-expire
  if (new Date(m.date + 'T23:59:00') < new Date()) {
    m.status = 'expired';
    monitors[idx] = m;
    await chrome.storage.local.set({ monitors });
    chrome.alarms.clear('monitor-' + monitorId);
    return;
  }

  try {
    const data = await fetchTeeTimes(m);
    const slots = parseSlots(data, m.timeFrom, m.timeTo, m.players);

    const currentKeys = new Set(slots.map(s => s.key));
    const monitorDismissed = (dismissedSlots[String(monitorId)] || []).filter(k => currentKeys.has(k));
    dismissedSlots[String(monitorId)] = monitorDismissed;

    const wasFound = m.status === 'found';
    const activeSlots = slots.filter(s => !monitorDismissed.includes(s.key));
    m.status = activeSlots.length > 0 ? 'found' : 'watching';
    m.lastChecked = checkedAt;
    m.lastSlots = slots;
    m.lastError = null;

    if (activeSlots.length > 0 && !wasFound) {
      const count = activeSlots.length;
      const city = COURSES[m.city];
      const dateLabel = friendlyDate(m.date, true);
      const timeLine = activeSlots.map(s => s.label).join(', ');
      const detailLine = [...new Set(activeSlots.map(s =>
        [cleanCourseName(s.courseName), cleanTwilightLabel(s.twilightLabel), s.priceLabel].filter(Boolean).join(' · ')
      ))].join(' | ');

      chrome.notifications.create('tee-found-' + m.id, {
        type: 'basic',
        iconUrl: 'icon128.png',
        title: `⛳ ${count} tee time${count > 1 ? 's' : ''} found — ${cleanCourseLabel(m.label)}`,
        message: dateLabel + ' · ' + timeLine + '\n' + detailLine,
        priority: 2,
        requireInteraction: true
      });

      if (m.alertEmail) {
        sendEmailAlert(m.alertEmail, m, activeSlots, city.bookingUrl);
      }
    }

    log.unshift({ course: m.label, date: m.date, time: checkedAt, slots, error: null });

  } catch (e) {
    m.status = 'error';
    m.lastChecked = checkedAt;
    m.lastSlots = [];
    m.lastError = e.message;
    log.unshift({ course: m.label, date: m.date, time: checkedAt, slots: [], error: e.message });
  }

  monitors[idx] = m;
  await chrome.storage.local.set({ monitors, log: log.slice(0, 200), dismissedSlots });
}

chrome.alarms.onAlarm.addListener(async alarm => {
  if (!alarm.name.startsWith('monitor-')) return;
  const monitorId = alarm.name.replace('monitor-', '');
  await runCheck(monitorId);
});

chrome.notifications.onClicked.addListener(async (notificationId) => {
  if (!notificationId.startsWith('tee-found-')) return;
  const monitorId = notificationId.replace('tee-found-', '');
  const { monitors = [] } = await chrome.storage.local.get(['monitors']);
  const m = monitors.find(x => String(x.id) === String(monitorId));
  const cityConfig = m && COURSES[m.city] ? COURSES[m.city] : COURSES.burnaby;
  chrome.tabs.create({ url: cityConfig.bookingUrl });
  chrome.notifications.clear(notificationId);
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.action === 'checkNow') {
    runCheck(String(msg.monitorId)).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.action === 'addMonitor') {
    (async () => {
      const { monitors = [], log = [] } = await chrome.storage.local.get(['monitors', 'log']);
      const m = { ...msg.monitor, id: String(msg.monitor.id), status: 'idle', lastChecked: null, lastSlots: [], lastError: null };
      monitors.push(m);
      await chrome.storage.local.set({ monitors, log });
      chrome.alarms.create('monitor-' + m.id, { periodInMinutes: m.interval / 60 });
      await runCheck(m.id);
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (msg.action === 'removeMonitor') {
    (async () => {
      const monitorId = String(msg.monitorId);
      const { monitors = [], log = [], dismissedSlots = {} } = await chrome.storage.local.get(['monitors', 'log', 'dismissedSlots']);
      const updated = monitors.filter(m => String(m.id) !== monitorId);
      delete dismissedSlots[monitorId];
      await chrome.storage.local.set({ monitors: updated, log, dismissedSlots });
      await chrome.alarms.clear('monitor-' + monitorId);
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (msg.action === 'pauseMonitor') {
    (async () => {
      const monitorId = String(msg.monitorId);
      const { monitors = [] } = await chrome.storage.local.get(['monitors']);
      const idx = monitors.findIndex(m => String(m.id) === monitorId);
      if (idx >= 0) {
        monitors[idx].status = 'paused';
        await chrome.storage.local.set({ monitors });
        await chrome.alarms.clear('monitor-' + monitorId);
      }
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (msg.action === 'resumeMonitor') {
    (async () => {
      const monitorId = String(msg.monitorId);
      const { monitors = [] } = await chrome.storage.local.get(['monitors']);
      const idx = monitors.findIndex(m => String(m.id) === monitorId);
      if (idx >= 0) {
        monitors[idx].status = 'watching';
        await chrome.storage.local.set({ monitors });
        chrome.alarms.create('monitor-' + monitorId, { periodInMinutes: monitors[idx].interval / 60 });
        await runCheck(monitorId);
      }
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (msg.action === 'dismissSlot') {
    (async () => {
      const monitorId = String(msg.monitorId);
      const { monitors = [], dismissedSlots = {} } = await chrome.storage.local.get(['monitors', 'dismissedSlots']);
      if (!dismissedSlots[monitorId]) dismissedSlots[monitorId] = [];
      if (!dismissedSlots[monitorId].includes(msg.slotKey)) dismissedSlots[monitorId].push(msg.slotKey);
      const idx = monitors.findIndex(x => String(x.id) === monitorId);
      if (idx >= 0) {
        const activeSlots = (monitors[idx].lastSlots || []).filter(s => !dismissedSlots[monitorId].includes(s.key));
        if (activeSlots.length === 0) monitors[idx].status = 'watching';
      }
      await chrome.storage.local.set({ dismissedSlots, monitors });
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (msg.action === 'toggle') {
    (async () => {
      const { beaconEnabled = true } = await chrome.storage.local.get('beaconEnabled');
      const nowEnabled = !beaconEnabled;
      await chrome.storage.local.set({ beaconEnabled: nowEnabled });
      await updateIcon(nowEnabled);
      if (nowEnabled) {
        // Resume — recreate alarms for all non-expired, non-paused monitors
        const { monitors = [] } = await chrome.storage.local.get('monitors');
        for (const m of monitors) {
          if (m.status !== 'expired' && m.status !== 'paused') {
            chrome.alarms.create('monitor-' + m.id, { periodInMinutes: m.interval / 60 });
            await runCheck(m.id);
          }
        }
      } else {
        // Pause — just clear alarms, don't touch monitor statuses
        await clearAllAlarms();
      }
      sendResponse({ enabled: nowEnabled });
    })();
    return true;
  }

  if (msg.action === 'getEnabled') {
    (async () => {
      const { beaconEnabled = true } = await chrome.storage.local.get('beaconEnabled');
      sendResponse({ enabled: beaconEnabled });
    })();
    return true;
  }
});
