// ── Config ──────────────────────────────────────────────────────────────────
const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbwUcIBqoU91ZIon_qpqZA8cz0vCyhuoq40aqD_EySdaEd6sgQpjO5PxKNeZ3IDwe-E/exec'; // filled in after deployment
const ADMIN_EMAIL = 'tkim485@gmail.com';

const TIMES = [
  ['6:00 AM','06:00'],['6:30 AM','06:30'],['7:00 AM','07:00'],['7:30 AM','07:30'],
  ['8:00 AM','08:00'],['8:30 AM','08:30'],['9:00 AM','09:00'],['9:30 AM','09:30'],
  ['10:00 AM','10:00'],['10:30 AM','10:30'],['11:00 AM','11:00'],['11:30 AM','11:30'],
  ['12:00 PM','12:00'],['12:30 PM','12:30'],['1:00 PM','13:00'],['1:30 PM','13:30'],
  ['2:00 PM','14:00'],['2:30 PM','14:30'],['3:00 PM','15:00'],['3:30 PM','15:30'],
  ['4:00 PM','16:00'],['4:30 PM','16:30'],['5:00 PM','17:00'],['5:30 PM','17:30'],
  ['6:00 PM','18:00']
];

const COURSE_GROUPS = [
  {
    city: 'burnaby',
    bookingUrl: 'https://golfburnaby.cps.golf/onlineresweb/search-teetime?TeeOffTimeMin=0&TeeOffTimeMax=23',
    groupLabel: '— Burnaby —',
    options: [
      { label: 'All Burnaby', ids: '1,2' },
      { label: 'Burnaby Mountain', ids: '1', indent: true },
      { label: 'Riverway', ids: '2', indent: true }
    ]
  },
  {
    city: 'vancouver',
    bookingUrl: 'https://golfvancouver.cps.golf/onlineresweb/search-teetime?TeeOffTimeMin=0&TeeOffTimeMax=23',
    groupLabel: '— Vancouver —',
    options: [
      { label: 'All Vancouver', ids: '1,2,3' },
      { label: 'Langara', ids: '1', indent: true },
      { label: 'Fraserview', ids: '2', indent: true },
      { label: 'McCleery', ids: '3', indent: true }
    ]
  }
];

// ── Helpers ──────────────────────────────────────────────────────────────────
function cleanCourseName(n) { return (n||'').replace(/Golf Course/gi,'').trim(); }
function cleanCourseLabel(l) { return (l||'').replace(/\bcourses\b/gi,'').replace(/\s+/g,' ').trim(); }
function cleanTwilightLabel(l) { return (l||'').replace(/^Twilight$/,'Twi'); }

async function sha256(message) {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2,'0')).join('');
}

function getDeviceId() {
  let id = localStorage.getItem('beacon_device_id');
  if (!id) {
    id = 'dev_' + Date.now() + '_' + Math.random().toString(36).slice(2);
    localStorage.setItem('beacon_device_id', id);
  }
  return id;
}

// ── Login ────────────────────────────────────────────────────────────────────
async function checkExistingSession() {
  const { beaconSession } = await chrome.storage.local.get('beaconSession');
  if (beaconSession) {
    showApp();
    return;
  }
  showLogin();
}

function showLogin() {
  document.getElementById('login-screen').style.display = 'block';
  document.getElementById('main-app').style.display = 'none';
}

function showApp() {
  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('main-app').style.display = 'block';
  initApp();
}

function setLoginError(msg) {
  const el = document.getElementById('login-error');
  el.textContent = msg;
  el.style.display = msg ? 'block' : 'none';
}

function setLoginLoading(loading) {
  const btn = document.getElementById('login-btn');
  btn.disabled = loading;
  btn.innerHTML = loading
    ? '<div class="spinner-sm"></div>'
    : (document.getElementById('password-field').style.display !== 'none' ? 'Enter Beacon' : 'Continue');
}

document.getElementById('login-email').addEventListener('input', () => {
  const email = document.getElementById('login-email').value.trim().toLowerCase();
  const isAdmin = email === ADMIN_EMAIL.toLowerCase();
  const pwField = document.getElementById('password-field');
  const btn = document.getElementById('login-btn');
  if (isAdmin && pwField.style.display === 'none') {
    pwField.style.display = 'block';
    btn.textContent = 'Enter Beacon';
  } else if (!isAdmin && pwField.style.display !== 'none') {
    pwField.style.display = 'none';
    btn.textContent = 'Continue';
  }
  setLoginError('');
});

document.getElementById('login-btn').addEventListener('click', async () => {
  const email = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  const isAdmin = email.toLowerCase() === ADMIN_EMAIL.toLowerCase();

  if (!email) { setLoginError('Please enter your email.'); return; }
  if (isAdmin && !password) { setLoginError('Please enter your admin password.'); return; }

  setLoginLoading(true);
  setLoginError('');

  try {
    const deviceId = getDeviceId();
    const body = { action: 'validate', email, deviceId };
    if (isAdmin) body.passwordHash = await sha256(password);

    const res = await fetch(APPS_SCRIPT_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    if (!res.ok) throw new Error('Could not reach server');
    const data = await res.json();

    if (data.success) {
      await chrome.storage.local.set({ beaconSession: { email, role: data.role, deviceId } });
      showApp();
    } else {
      const messages = {
        not_on_list: 'This email is not on the access list. Contact the admin to request access.',
        revoked: 'Your access has been revoked. Contact the admin.',
        max_instances: 'Maximum devices reached for this account. Contact the admin to add more.',
        wrong_password: 'Incorrect password.',
        server_error: 'Server error. Please try again.'
      };
      setLoginError(messages[data.reason] || 'Access denied.');
    }
  } catch (e) {
    // Fail closed
    setLoginError('Could not connect to the access server. Please try again.');
  }

  setLoginLoading(false);
});

document.getElementById('login-password').addEventListener('keydown', e => {
  if (e.key === 'Enter') document.getElementById('login-btn').click();
});
document.getElementById('login-email').addEventListener('keydown', e => {
  if (e.key === 'Enter') document.getElementById('login-btn').click();
});

// ── App init ─────────────────────────────────────────────────────────────────
let selectedCourses = [];
let dropdownOpen = false;
let appInitialized = false;

function initApp() {
  if (appInitialized) { refresh(); return; }
  appInitialized = true;

  buildCourseDropdown();
  buildTimeOptions('time-from','07:00');
  buildTimeOptions('time-to','10:00');

  const todayStr = new Date().toISOString().slice(0,10);
  document.getElementById('date-input').value = todayStr;
  document.getElementById('date-input').min = todayStr;

  chrome.storage.local.get('alertEmail', ({alertEmail}) => {
    if (alertEmail) document.getElementById('email-input').value = alertEmail;
  });
  document.getElementById('email-input').addEventListener('change', e => {
    chrome.storage.local.set({ alertEmail: e.target.value.trim() });
  });

  document.getElementById('add-btn').addEventListener('click', addMonitor);
  document.getElementById('tab-setup').addEventListener('click', ()=>switchTab('setup'));
  document.getElementById('tab-log').addEventListener('click', ()=>switchTab('log'));
  document.getElementById('tab-advanced').addEventListener('click', ()=>switchTab('advanced'));

  // Load advanced settings
  chrome.storage.local.get('advancedSettings', ({advancedSettings={}}) => {
    if (advancedSettings.discordWebhook) document.getElementById('discord-webhook').value = advancedSettings.discordWebhook;
    if (advancedSettings.dailyEmailCap) document.getElementById('email-cap').value = advancedSettings.dailyEmailCap;
    if (advancedSettings.overnightMode) document.getElementById('overnight-toggle').checked = true;
  });

  // Save advanced settings on change
  function saveAdvanced() {
    const cap = document.getElementById('email-cap').value.trim();
    chrome.storage.local.set({ advancedSettings: {
      discordWebhook: document.getElementById('discord-webhook').value.trim(),
      dailyEmailCap: cap ? parseInt(cap) : null,
      overnightMode: document.getElementById('overnight-toggle').checked
    }});
  }
  document.getElementById('discord-webhook').addEventListener('change', saveAdvanced);
  document.getElementById('email-cap').addEventListener('change', saveAdvanced);
  document.getElementById('overnight-toggle').addEventListener('change', saveAdvanced);

  // Clear all monitors
  document.getElementById('clear-all-btn').addEventListener('click', async () => {
    if (!confirm('Clear all monitors, logs and history? This cannot be undone.')) return;
    const { beaconSession, alertEmail, advancedSettings } = await chrome.storage.local.get(['beaconSession','alertEmail','advancedSettings']);
    await chrome.storage.local.clear();
    await chrome.storage.local.set({ beaconSession, alertEmail, advancedSettings });
    // Clear all alarms
    await chrome.alarms.clearAll();
    await refresh();
  });
  document.getElementById('toggle-btn').addEventListener('click', async () => {
    const r = await chrome.runtime.sendMessage({action:'toggle'});
    renderToggle(r.enabled);
    await refresh();
  });
  document.getElementById('panel-setup').addEventListener('click', e => {
    const c = e.target.closest('[data-action]');
    if (!c) return;
    const id = String(c.dataset.id);
    const action = c.dataset.action;
    if (action==='check') checkNow(id);
    if (action==='remove') removeMonitor(id);
    if (action==='pause') pauseMonitor(id);
    if (action==='resume') resumeMonitor(id);
  });
  document.getElementById('alerts-area').addEventListener('click', e => {
    const btn = e.target.closest('.dismiss-btn');
    if (btn) dismissSlot(btn.dataset.monitorId, btn.dataset.slotKey);
  });

  refresh();
  setInterval(refresh, 5000);
}

// ── Course dropdown ───────────────────────────────────────────────────────────
function buildCourseDropdown() {
  const dropdown = document.getElementById('course-dropdown');
  dropdown.innerHTML = COURSE_GROUPS.map(group =>
    `<div class="dd-group-label">${group.groupLabel}</div>` +
    group.options.map(opt =>
      `<div class="dd-option${opt.indent?' dd-individual':''}" data-city="${group.city}" data-ids="${opt.ids}" data-label="${opt.label}">
        <span class="check"></span>${opt.label}
      </div>`
    ).join('')
  ).join('') +
  `<div class="dd-footer">
    <button class="dd-btn-deselect" id="dd-deselect">Deselect all</button>
    <button class="dd-btn-done" id="dd-done">Done</button>
  </div>`;

  dropdown.addEventListener('mousedown', e => {
    const opt = e.target.closest('.dd-option');
    if (opt) {
      e.preventDefault();
      const { city, ids, label } = opt.dataset;
      const isAllGroup = !opt.classList.contains('dd-individual');
      const existingIdx = selectedCourses.findIndex(c=>c.city===city&&c.ids===ids);
      if (existingIdx >= 0) {
        selectedCourses.splice(existingIdx, 1);
      } else {
        if (isAllGroup) {
          selectedCourses = selectedCourses.filter(c=>c.city!==city);
        } else {
          const group = COURSE_GROUPS.find(g=>g.city===city);
          selectedCourses = selectedCourses.filter(c=>!(c.city===city&&c.ids===group.options[0].ids));
        }
        selectedCourses.push({ city, ids, label });
      }
      renderDropdown();
      return;
    }
    if (e.target.closest('#dd-done')) { e.preventDefault(); closeDropdown(); return; }
    if (e.target.closest('#dd-deselect')) { e.preventDefault(); selectedCourses=[]; renderDropdown(); return; }
  });

  document.getElementById('course-trigger').addEventListener('click', () => {
    dropdownOpen = !dropdownOpen;
    document.getElementById('course-dropdown').style.display = dropdownOpen ? 'block' : 'none';
    document.getElementById('course-trigger').classList.toggle('open', dropdownOpen);
  });

  document.addEventListener('click', e => {
    if (!document.getElementById('course-selector-wrap').contains(e.target)) closeDropdown();
  });
}

function closeDropdown() {
  dropdownOpen = false;
  document.getElementById('course-dropdown').style.display = 'none';
  document.getElementById('course-trigger').classList.remove('open');
}

function renderDropdown() {
  const t = document.getElementById('course-trigger-text');
  if (selectedCourses.length) {
    t.textContent = selectedCourses.map(c=>c.label).join(', ');
    t.classList.remove('placeholder');
  } else {
    t.textContent = 'Select courses...';
    t.classList.add('placeholder');
  }
  document.querySelectorAll('.dd-option').forEach(el => {
    const active = selectedCourses.some(c=>c.city===el.dataset.city&&c.ids===el.dataset.ids);
    el.classList.toggle('selected', active);
    el.querySelector('.check').textContent = active ? '✓' : '';
  });
}

function buildTimeOptions(selectId, defaultVal) {
  const el = document.getElementById(selectId);
  TIMES.forEach(([label,val]) => {
    const o = document.createElement('option');
    o.value=val; o.textContent=label;
    if (val===defaultVal) o.selected=true;
    el.appendChild(o);
  });
}

// ── Monitor actions ───────────────────────────────────────────────────────────
function switchTab(name) {
  document.querySelectorAll('.tab').forEach((t,i)=>t.classList.toggle('active',['setup','log','advanced'][i]===name));
  document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active',p.id==='panel-'+name));
}

function fmt12(hhmm) {
  const [h,m]=hhmm.split(':').map(Number);
  return (h%12||12)+':'+String(m).padStart(2,'0')+' '+(h<12?'AM':'PM');
}
function dateLabel(d) { return new Date(d+'T12:00:00').toLocaleDateString('en-CA',{weekday:'short',month:'short',day:'numeric'}); }
function friendlyDate(d) { return new Date(d+'T12:00:00').toLocaleDateString('en-CA',{weekday:'long',month:'long',day:'numeric'}); }

async function addMonitor() {
  const date = document.getElementById('date-input').value;
  const timeFrom = document.getElementById('time-from').value;
  const timeTo = document.getElementById('time-to').value;
  const players = document.getElementById('players-select').value;
  const interval = parseInt(document.getElementById('interval-select').value);
  const alertEmail = document.getElementById('email-input').value.trim();

  if (!date) { alert('Please select a date.'); return; }
  if (timeFrom >= timeTo) { alert('Earliest time must be before latest time.'); return; }
  if (!selectedCourses.length) { alert('Please select at least one course.'); return; }

  const byCity = {};
  selectedCourses.forEach(c=>{ if (!byCity[c.city]) byCity[c.city]=[]; byCity[c.city].push(c); });

  for (const city of Object.keys(byCity)) {
    const courses = byCity[city];
    const courseIds = [...new Set(courses.flatMap(c=>c.ids.split(',')))].join(',');
    const label = courses.map(c=>c.label).join(', ');
    const id = String(Date.now())+String(Math.floor(Math.random()*1000));
    await chrome.runtime.sendMessage({action:'addMonitor',monitor:{id,city,courseIds,label,courseName:label,date,timeFrom,timeTo,players,interval,alertEmail}});
  }
  selectedCourses=[]; renderDropdown();
  document.getElementById('email-input').value = '';
  await refresh();
}

async function removeMonitor(id) { await chrome.runtime.sendMessage({action:'removeMonitor',monitorId:String(id)}); await refresh(); }
async function checkNow(id) { await chrome.runtime.sendMessage({action:'checkNow',monitorId:String(id)}); setTimeout(refresh,2500); }
async function pauseMonitor(id) { await chrome.runtime.sendMessage({action:'pauseMonitor',monitorId:String(id)}); await refresh(); }
async function resumeMonitor(id) { await chrome.runtime.sendMessage({action:'resumeMonitor',monitorId:String(id)}); setTimeout(refresh,2500); }
async function dismissSlot(monitorId,slotKey) { await chrome.runtime.sendMessage({action:'dismissSlot',monitorId:String(monitorId),slotKey}); await refresh(); }

async function refresh() {
  const {monitors=[],log=[],dismissedSlots={},beaconEnabled=true} = await chrome.storage.local.get(['monitors','log','dismissedSlots','beaconEnabled']);
  renderToggle(beaconEnabled);
  renderAlerts(monitors,dismissedSlots);
  renderMonitors(monitors,dismissedSlots);
  renderLog(log);
}

function renderToggle(enabled) {
  const btn = document.getElementById('toggle-btn');
  btn.textContent = enabled?'On':'Off';
  btn.className = 'toggle-btn '+(enabled?'toggle-on':'toggle-off');
}

function renderAlerts(monitors,dismissedSlots) {
  const found = monitors.filter(m=>m.status==='found'&&m.lastSlots?.length);
  document.getElementById('alerts-area').innerHTML = found.map(m=>{
    const dismissed=dismissedSlots[String(m.id)]||[];
    const activeSlots=m.lastSlots.filter(s=>!dismissed.includes(s.key));
    if (!activeSlots.length) return '';
    const group=COURSE_GROUPS.find(g=>g.city===m.city);
    const bookingUrl=group?group.bookingUrl:'#';
    const slotsHtml=activeSlots.map(s=>{
      const isTwi=!!s.twilightLabel;
      const parts=[s.label,cleanCourseName(s.courseName),cleanTwilightLabel(s.twilightLabel),s.priceLabel].filter(Boolean);
      return `<div class="slot-pill${isTwi?' slot-pill-twi':''}">
        <span class="slot-info">${parts.join(' · ')}</span>
        <div class="slot-actions">
          <a href="${bookingUrl}" target="_blank" class="book-link">Book →</a>
          <button class="dismiss-btn" data-monitor-id="${m.id}" data-slot-key="${s.key}">Dismiss</button>
        </div>
      </div>`;
    }).join('');
    return `<div class="alert-banner">
      <div class="alert-header">⛳ ${cleanCourseLabel(m.label)}</div>
      <div class="alert-date">${friendlyDate(m.date)}</div>
      ${slotsHtml}
    </div>`;
  }).join('');
}

function renderMonitors(monitors,dismissedSlots) {
  const el=document.getElementById('monitors-list');
  if (!monitors.length) { el.innerHTML='<div class="empty">No monitors yet</div>'; return; }
  el.innerHTML=monitors.map(m=>{
    const isExpired=m.status==='expired';
    const isPaused=m.status==='paused';
    const isActive=!isExpired&&!isPaused;
    const dotCls=m.status==='found'?'dot-found':m.status==='error'?'dot-error':(isExpired||isPaused)?'dot-idle':'dot-watching';
    const badgeCls=m.status==='found'?'badge-found':m.status==='error'?'badge-error':(isExpired||isPaused)?'badge-none':'badge-watching';
    const badgeTxt={found:'available!',checking:'checking...',error:'error',watching:'watching',idle:'starting',expired:'expired',paused:'paused'}[m.status]||m.status;
    const intervalLabel=m.interval>=60?m.interval/60+' min':m.interval+'s';
    const playersLabel=m.players==='0'?'any':m.players+'p';
    const checkedLabel=m.lastChecked?'Checked '+m.lastChecked:'Starting...';
    const dismissed=dismissedSlots[String(m.id)]||[];
    const activeSlots=(m.lastSlots||[]).filter(s=>!dismissed.includes(s.key));
    const slotsHtml=activeSlots.length
      ?'<div style="padding-left:13px;margin-top:4px">'+activeSlots.map(s=>{
          const isTwi=!!s.twilightLabel;
          const parts=[s.label,cleanCourseName(s.courseName),cleanTwilightLabel(s.twilightLabel),s.priceLabel].filter(Boolean).join(' · ');
          return `<span class="tee-slot${isTwi?' tee-slot-twi':''}">${parts}</span>`;
        }).join('')+'</div>':''
    const errorHtml=m.lastError?`<div class="monitor-detail" style="color:#854F0B">${m.lastError}</div>`:'';
    const statusNote=isExpired?'Date passed — remove when ready':isPaused?'Paused — click ▶ to resume':checkedLabel;
    const emailNote=m.alertEmail?`<div class="monitor-detail">📧 ${m.alertEmail}</div>`:'';
    const pauseBtn=isActive?`<button class="icon-btn icon-btn-pause" data-action="pause" data-id="${m.id}" title="Pause">⏸</button>`:'';
    const resumeBtn=isPaused?`<button class="icon-btn icon-btn-resume" data-action="resume" data-id="${m.id}" title="Resume">▶</button>`:'';
    const checkBtn=isActive?`<button class="icon-btn" data-action="check" data-id="${m.id}" title="Check now">↺</button>`:'';
    const removeBtn=`<button class="icon-btn" data-action="remove" data-id="${m.id}" title="Remove">✕</button>`;
    return `<div class="monitor-item">
      <div class="monitor-top">
        <div class="dot ${dotCls}"></div>
        <div class="monitor-name">${cleanCourseLabel(m.label)}</div>
        <span class="badge ${badgeCls}">${badgeTxt}</span>
        <div class="monitor-actions">${pauseBtn}${resumeBtn}${checkBtn}${removeBtn}</div>
      </div>
      <div class="monitor-detail">${dateLabel(m.date)} · ${fmt12(m.timeFrom)}–${fmt12(m.timeTo)} · ${playersLabel}${isActive?' · every '+intervalLabel:''}</div>
      ${emailNote}${errorHtml}
      <div class="monitor-detail">${statusNote}</div>
      ${slotsHtml}
    </div>`;
  }).join('');
}

function renderLog(log) {
  const el=document.getElementById('log-list');
  if (!log.length) { el.innerHTML='<div class="empty">No checks run yet</div>'; return; }
  el.innerHTML=log.map(entry=>{
    const badgeCls=entry.error?'badge-error':entry.slots?.length?'badge-found':'badge-none';
    const badgeTxt=entry.error?'error':entry.slots?.length?entry.slots.length+' found':'none';
    const detail=entry.error?entry.error:entry.slots?.length
      ?entry.slots.map(s=>[s.label,cleanCourseName(s.courseName),cleanTwilightLabel(s.twilightLabel)].filter(Boolean).join(' · ')).join(', ')
      :'No availability in window';
    return `<div class="log-row">
      <div class="log-top">
        <span class="log-label">${cleanCourseLabel(entry.course)} · ${dateLabel(entry.date)}</span>
        <span>${entry.time} <span class="badge ${badgeCls}">${badgeTxt}</span></span>
      </div>
      <div class="log-detail">${detail}</div>
    </div>`;
  }).join('');
}

// ── Boot ──────────────────────────────────────────────────────────────────────
checkExistingSession();
